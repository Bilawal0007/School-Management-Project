package com.bms.schoolmanagementsystem.dto;

public record ClassroomStudentDto(
        String id,
        String firstName,
        String lastName,
        String nationalId,
        String studentNumber
) {
}
