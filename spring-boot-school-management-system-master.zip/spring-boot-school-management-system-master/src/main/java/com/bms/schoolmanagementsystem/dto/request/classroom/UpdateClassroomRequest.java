package com.bms.schoolmanagementsystem.dto.request.classroom;

public class UpdateClassroomRequest extends BaseClassroomRequest{
}
