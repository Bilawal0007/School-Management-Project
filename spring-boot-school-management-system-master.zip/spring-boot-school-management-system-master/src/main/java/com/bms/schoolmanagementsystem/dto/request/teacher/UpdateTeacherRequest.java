package com.bms.schoolmanagementsystem.dto.request.teacher;

public class UpdateTeacherRequest extends BaseTeacherRequest{
}
