package com.bms.schoolmanagementsystem.exception.classroom;

public class ClassroomNotFoundException extends RuntimeException {
    public ClassroomNotFoundException(String message) {
        super(message);
    }
}
